import type { NextConfig } from 'next';
const config: NextConfig = {poweredByHeader:false, serverExternalPackages:['@raydium-io/raydium-sdk-v2'],async headers(){return[{source:'/(.*)',headers:[{key:'X-Content-Type-Options',value:'nosniff'},{key:'Referrer-Policy',value:'strict-origin-when-cross-origin'},{key:'X-Frame-Options',value:'DENY'}]}]}};
export default config;
